<?php
require_once("index.php");
?>

<div class="wrapper container" style="margin-bottom:10px; margin-top:100px;">
    <div class="alert alert-danger">
        Une erreur s'est produite, contactez l'administrateur pour avoir plus d'information !
    </div>
</div>